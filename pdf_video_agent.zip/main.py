from agent.pipeline import run_agent

if __name__ == "__main__":
    run_agent()