from agent.watcher import watch_folder

def run_agent():
    watch_folder()